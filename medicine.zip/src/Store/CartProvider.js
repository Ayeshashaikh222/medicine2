import { useEffect, useState } from "react";
import CartContext from "./CartContext";
import axios from "axios";
// import { wait } from "@testing-library/user-event/dist/utils";



const CartProvider = (props) => {

    const [items, setItems] = useState([]);
    const [totalAmount, setTotalAmount] = useState(0);



    useEffect(() => {
        let amount = 0;
        items.forEach((item) => {
            amount = item.price * item.quantity;
        });
        setTotalAmount(amount);
    }, [items]);


    const addItemHandler = (item, quantity) => {
        setItems((prevItems) => {
            const existingItem = prevItems.find((prevItem) => prevItem.id === item.id );

            if(existingItem){
                return prevItems.map((prevItem) => prevItem.id === item.id ? {...prevItem, quantity: prevItem.quantity + quantity} : prevItem );
            };

            try{
                const response = axios.post('https://crudcrud.com/api/413a233affe648aebca273f960993dd6/Cart',...prevItems, {...item, quantity: quantity})
                if(!response.ok){
                    console.log("something went wrong");
                } else {
                    console.log("successful");
                   
                }
            } catch (error) {
                console.log(error)
            }


            return [...items, {...item, quantity: quantity}];
    });

    
     }

    // const addItemHandler = async (item, quantity) => {
    //     const existingItemIndex = items.findIndex((prevItem) => prevItem.id === item.id);
      
    //     if (existingItemIndex !== -1) {
    //       const updatedItems = [...items];
    //       updatedItems[existingItemIndex].quantity += quantity;
    //       setItems(updatedItems);
    //     } else {
    //       try {
    //         const response = await axios.post('https://crudcrud.com/api/b046e71fae1643ec9c6ad7a719045a55/Cart',{ ...item, quantity });
    //         if (!response.ok) {
    //           console.log("Something went wrong");
    //         } else {
    //           console.log("Successful");
    //           const newItem = { ...item, quantity: quantity };
    //           setItems((prevItems) => [...prevItems, newItem]);
    //         }
    //       } catch (error) {
    //         console.log(error);
    //       }
    //     }
    //   };

const clearCartHandler = () => {
    setItems([])
};

// const fetchProducts = async () => {
//     try {
//         const response = await axios.get('https://crudcrud.com/api/b046e71fae1643ec9c6ad7a719045a55/Cart')
//         if (response.status === 200) {
//             const data = await response.data;
//             setItems(data)
//             console.log(data);
//         } else {
//             console.log("Something went wrong with the request.");
//         }
//     } catch (error) {
//         console.log("Error:", error.message);
//     }

// };

const fetchPrducts = async ()=>{


    try {
      const response = await fetch.get('https://crudcrud.com/api/413a233affe648aebca273f960993dd6/Cart')
      if(!response.ok){
        console.log('something went wrong')
      }
      const data = await response.json()

    } catch (error) {
      console.log(error.message)
    }

  }


const cartContext = {
    items: items,
    totalAmount: totalAmount,
    addItem: addItemHandler,
    clearCart: clearCartHandler,
    getItems: fetchPrducts
}


return (
    <CartContext.Provider value={cartContext}>
        {props.children}
    </CartContext.Provider>
);
}

export default CartProvider;